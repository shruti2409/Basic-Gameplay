# Basic Gameplay

## Feed Animals (With Bonus Features)

Scene -> Prototype 2

Game link -> [Feed Animals](https://play.unity.com/mg/other/feedanimals-2)

![Feed Animals](./feedanimals.png)

## Play Fetch (Challenge)

Scene -> PlayFetch

![Play Fetch](./playfetch.png)
